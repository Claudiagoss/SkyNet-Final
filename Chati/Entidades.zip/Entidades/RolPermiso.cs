﻿namespace Tickets.Api.Entidades;

public class RolPermiso
{
    public int RolPermisoId { get; set; }
    public int RolId { get; set; }
    public int PermisoId { get; set; }
}
