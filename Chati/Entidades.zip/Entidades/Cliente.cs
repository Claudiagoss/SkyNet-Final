﻿public class Cliente
{
    public int ClienteId { get; set; }
    public string? Nombre { get; set; }
    public string? Contacto { get; set; }
    public string? Email { get; set; }
    public string? Telefono { get; set; }
    public string? Direccion { get; set; }
    public string? Departamento { get; set; }
    public DateTime? CreadoEl { get; set; }
}
