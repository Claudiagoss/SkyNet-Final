﻿namespace Tickets.Api.Entidades;

public class PrioridadTicket
{
    public int PrioridadId { get; set; }
    public string Nombre { get; set; } = null!;
    public int Peso { get; set; }
}
